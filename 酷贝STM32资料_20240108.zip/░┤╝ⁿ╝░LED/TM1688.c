// TM1668��ʾ�밴������ 
 
 

#define SDA_TM1668    p3_4 

#define CLK_TM1668    p3_5 

#define STB_TM1668    p3_7 
 

//�����Ƿ���tm1668���ݺ��� 

void Send_data(unsigned char dat)    

{    
 
unsigned char i;    
 
for(i=0;i<8;i++)    
  
{    
   
CLK_TM1668=0;    
   
if(dat & (1 << i))  
{
SDA_TM1668=1;
}    
     
else  
{
SDA_TM1668=0;
}    
   
//asm("nop");   
   asm("nop");     
   
CLK_TM1668=1;        
  
}    
   
//CLK_TM1668=0;    

} 
 
 

//�����ǽ���tm1668���ݺ��� 

unsigned char Incept_data(void)    

{    
 
unsigned char i;  
 
unsigned char tm1668_date;  
 
tm1668_date=0; 
 
pd3_4=0;//������Ϊ�����   
 
CLK_TM1668=0;   
 
for(i=0;i<8;i++)    
  
{    
  
// asm("nop");  
   
CLK_TM1668=1;  
   
tm1668_date=tm1668_date>>1;    //�ȶ������ǵ�λ 
   
if(SDA_TM1668)
{
tm1668_date=tm1668_date|0x80;
} 
   
else
{
tm1668_date=tm1668_date&0x7f; 
} 
   
//asm("nop");   
   //asm("nop");     
   
CLK_TM1668=0;        
  
}    
   
//CLK_TM1668=0; www.docin.com   
pd3_4=1;//������Ϊ�����   
   
//asm("nop"); 
   
return(tm1668_date);     

} 
 

//���������� 

void read_key (void) 

{ 
 
//STB_TM1668=1;    
 
    
STB_TM1668=0;      
    
Send_data(0x42); 
//���������� 
 
asm("nop");  
 asm("nop"); 
 asm("nop");  
 
asm("nop");  
 asm("nop"); 
 asm("nop");    
 
//delay_tm1668();//1us��ʱ 
 
key_data1=Incept_data();  
 
key_data2=Incept_data(); 

 key_data3=Incept_data(); 
 
key_data4=Incept_data(); 
 
key_data5=Incept_data(); 
 
//asm("nop");   
 
STB_TM1668=1;     

} 
 
 

void DIS_1668(unsigned char data1,unsigned char data2,unsigned char data3,unsigned 
char data4)    

{       
  
    
STB_TM1668=0;    
    
Send_data(0x03); //������ʾģʽ��4λ14��     
        
    
STB_TM1668=1;    
    
asm("nop");   
    
STB_TM1668=0;      
    
//Send_data(0x44); //�̶���ַ  
 
Send_data(0x40); //�Զ��ۼӵ�ַ        
            
    
STB_TM1668=1;    
    
asm("nop");   
STB_TM1668=0;      
    
Send_data(0xC0); //���͵�ַ     
    
Send_data(data1);    
  
 
//STB_TM1668=1;    
    
//asm("nop");   
    
//STB_TM1668=0;     
    
//Send_data(0xC1); //���͵�ַ     
    
Send_data(0x0);//�𷢹�� 
        
    
//STB_TM1668=1;    
    
//asm("nop");   
    
//STB_TM1668=0;       
    
//Send_data(0xC2); //���͵�ַ     
    
Send_data(data2);   
  
 
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC3); //���͵�ַ     
    
Send_data(0x0);//�𷢹��  
        
    
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;      
    
//Send_data(0xC4); //���͵�ַ     
    
Send_data(data3);   
  
 
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC5); //���͵�ַ     
    
Send_data(0x0);//�𷢹��  
        
    
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC6); //���͵�ַ     
    
Send_data(data4); 
  
 
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC7); //���͵�ַ    
Send_data(0x0);//�𷢹��    
 
// 
 //STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC8); //���͵�ַ     
    
Send_data(0x0);  
  
 
//STB_TM1668=1;    
    
//asm("nop");  
    
//STB_TM1668=0;     
    
//Send_data(0xC9); 
//���͵�ַ     
    
Send_data(0x0);
//�𷢹�� 
 // 
 
//STB_TM1668=1;    
    
//asm("nop");  
   
// STB_TM1668=0;     
    
//Send_data(0xCa); //���͵�ַ     
    
Send_data(0x0); 
  
 
//STB_TM1668=1;    
    
//asm("nop");  
   
// STB_TM1668=0;     
   
// Send_data(0xCb); 
//���͵�ַ     
    
Send_data(0x0);
//�𷢹�� 
 // 
 
//STB_TM1668=1;    
   
// asm("nop");   
   
// STB_TM1668=0;     
   
// Send_data(0xCc); //���͵�ַ     
    
Send_data(0x0); 
  
 
//STB_TM1668=1;    
 
//asm("nop");   
    
//STB_TM1668=0;     
   
// Send_data(0xCd); //���͵�ַ     
    
Send_data(0x0);//�𷢹�� 
 // 
        
   
 STB_TM1668=1;    

 asm("nop");   
    
STB_TM1668=0;      
    
Send_data(0x89); //����ʾ    
 
STB_TM1668=1;    
}   
