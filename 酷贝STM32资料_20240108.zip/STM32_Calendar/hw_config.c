/**
  ******************************************************************************
  * @file    hw_config.c 
  * @author  MCU Shanghai Team
  * @version V3.1.0
  * @date    08/19/2009
  * @brief   Configuration for hardware on STM3210E-LK.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "hw_config.h"
#include "misc.h"
#include "lcd.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
ErrorStatus HSEStartUpStatus;
bool RTCinfo_Done = FALSE;
uint8_t RTCinfo[12] = {0};
uint8_t RTCinfo_index = 0;
bool DisplayReady = FALSE;

// ZYMG12864
/*A0=0  -- cmd*/
#define LCD_Command  *((volatile unsigned char * )0x6c000000)
/*A0=1 -- data*/
#define LCD_Data  *((volatile unsigned char * )0x6c000001)

/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
static void RCC_Config(void);
/* Private functions ---------------------------------------------------------*/


/**
  * @brief  Configures Main system clocks & power and initialize LCD
  * @param  None
  * @retval None
  */
void Set_System(void)
{ 
  /* RCC configuration */
  RCC_Config();

  STM3210E_LCD_Init();
}


/**
  * @brief  Configures interrupt used in application
  * @param  None
  * @retval None
  */
void Interrupts_Config(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);


  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  
  /* Enable the EXTI11~15 Interrupt on JoyStick PB.11~15 */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
    /* Enable the RTC Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}



/**
  * @brief  Configures clock in system
  * @param  None
  * @retval None
  */
static void RCC_Config(void)
{

  /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if (HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);

    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1);

    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1);

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

    /* Enable PLL */
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {}

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSYSCLKSource() != 0x08)
    {}
    
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF|RCC_APB2Periph_GPIOB|
                           RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE|
                           RCC_APB2Periph_GPIOG|RCC_APB2Periph_AFIO, ENABLE);
    EXTI_DeInit();
    NVIC_DeInit();
  }
}

/**
  * @brief  Configures GPIO of LED 
  * @param  None
  * @retval None
  */
void LedGPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
}

/**
  * @brief  Configures GPIO and EXTI for joystick
  * @param  None
  * @retval None
  */
void JoyStick_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;
  
  /* Configure the JoyStick IOs */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

    
  EXTI_ClearITPendingBit(EXTI_Line11);
  EXTI_ClearITPendingBit(EXTI_Line12);
  EXTI_ClearITPendingBit(EXTI_Line13);
  EXTI_ClearITPendingBit(EXTI_Line14);
  EXTI_ClearITPendingBit(EXTI_Line15);
  
  /* for 5 direction of joystick----------------------------------------------*/
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource11);
  EXTI_InitStructure.EXTI_Line = EXTI_Line11;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource12);
  EXTI_InitStructure.EXTI_Line = EXTI_Line12;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
 
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource13);
  EXTI_InitStructure.EXTI_Line = EXTI_Line13;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource14);
  EXTI_InitStructure.EXTI_Line = EXTI_Line14;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource15);
  EXTI_InitStructure.EXTI_Line = EXTI_Line15;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
}

/**
  * @brief  reset NVIC register
  * @param  None
  * @retval None
  */
void NVIC_DeInit(void)
{
  uint32_t index = 0;
  
  NVIC->ICER[0] = 0xFFFFFFFF;
  NVIC->ICER[1] = 0x0FFFFFFF;
  NVIC->ICPR[0] = 0xFFFFFFFF;
  NVIC->ICPR[1] = 0x0FFFFFFF;
  
  for(index = 0; index < 0x30; index++)
  {
     NVIC->IP[index] = 0x00000000;
  } 
}

/**
  * @brief  Display menu1 for user to input time information on LCD
  * @param  None
  * @retval None
  */
void LCD_Menu1(void)
{
    /* display string "����������Ϣ" */
    LCD_DrawChineseString(0, 0, String1, 6);  
    LCD_DrawChar(0, 96, 21);
    /* _ _�� _ _�� _ _�� */
    LCD_DrawChar(2, 0, 22);
    LCD_DrawChar(2, 8, 23);
    LCD_DrawChineseChar(2, 16, 127);
  
    LCD_DrawChar(2, 32, 23);
    LCD_DrawChar(2, 40, 23);
    LCD_DrawChineseChar(2, 48, 129);
    
    LCD_DrawChar(2, 64, 23);
    LCD_DrawChar(2, 72, 23);
    LCD_DrawChineseChar(2, 80, 131);
    /* _ _ʱ _ _�� _ _�� */
    LCD_DrawChar(4, 0, 23);
    LCD_DrawChar(4, 8, 23);
    LCD_DrawChineseChar(4, 16, 145);
  
    LCD_DrawChar(4, 32, 23);
    LCD_DrawChar(4, 40, 23);
    LCD_DrawChineseChar(4, 48, 147);
    
    LCD_DrawChar(4, 64, 23);
    LCD_DrawChar(4, 72, 23);
    LCD_DrawChineseChar(4, 80, 149);
}

/**
  * @brief  Display menu1 to show reset information on LCD
  * @param  None
  * @retval None
  */
void LCD_Menu2(void)
{
  if (RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET)
  {
    /* display string "�ϵ縴λ������" */
    LCD_DrawChineseString(0, 0, String3, 4); 
    LCD_DrawString(0, 64, String6, 3);
  }
  else if (RCC_GetFlagStatus(RCC_FLAG_PINRST) != RESET)
  {
    /* display string "�ⲿ��λ������" */
    LCD_DrawChineseString(0, 0, String4, 4); 
    LCD_DrawString(0, 64, String6, 3);
  }
  
    LCD_DrawChineseChar(2, 16, 127);
    LCD_DrawChineseChar(2, 48, 129);
    LCD_DrawChineseChar(2, 80, 131);
    LCD_DrawChineseChar(4, 16, 145);
    LCD_DrawChineseChar(4, 48, 147);
    LCD_DrawChineseChar(4, 80, 149);
    
  /* display string "��������RTC" */
  LCD_DrawChineseString(6, 0, String5, 4);  
  LCD_DrawString(6, 64, String7, 3);

}

/**
  * @brief  disable EXTI interrupt
  * @param  None
  * @retval None
  */
void DIS_EXTI(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
          
  /* Disable the EXTI11~15 Interrupt on JoyStick PB.11~15 */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
  NVIC_Init(&NVIC_InitStructure);
}

/**
  * @brief  Configuration RTC to generate second interrupt
  * @param  None
  * @retval None
  */
void RTC_Configuration(void)
{
  /* Enable PWR and BKP clocks */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

  /* Allow access to BKP Domain */
  PWR_BackupAccessCmd(ENABLE);

  /* Reset Backup Domain */
  BKP_DeInit();

  /* Enable LSE */
  RCC_LSEConfig(RCC_LSE_ON);
  /* Wait till LSE is ready */
  while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
  {}

  /* Select LSE as RTC Clock Source */
  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);

  /* Enable RTC Clock */
  RCC_RTCCLKCmd(ENABLE);

  RTC_WaitForLastTask();
  
  /* Wait for RTC registers synchronization */
  RTC_WaitForSynchro();

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();

  /* Enable the RTC Second */
  RTC_ITConfig(RTC_IT_SEC, ENABLE);

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();

  /* Set RTC prescaler: set RTC period to 1sec */
  RTC_SetPrescaler(32767); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
}

/**
  * @brief  set current counter value to RTC
  * @param  None
  * @retval None
  */
void Time_Adjust(void)
{
  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
  /* Change the current time */
  RTC_SetCounter(Time_Regulate());
  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
}


/*RTCinfo[0]~[11]*/
/* [0][1] -- Year */
/* [2][3] -- Month */
/* [4][5] -- Day */
/* [6][7] -- Hour */
/* [8][9] -- Minute */
/* [10][11] -- Second */
u32 Month_Days_Accu_C[13] = {0,31,59,90,120,151,181,212,243,273,304,334,365};
u32 Month_Days_Accu_L[13] = {0,31,60,91,121,152,182,213,244,274,305,335,366};
#define SecsPerDay (3600*24)

/**
  * @brief  caculate total number of seconds from user input time information
  * @param  None
  * @retval total number of seconds
  */
u32 Time_Regulate(void)
{
  u32 Tmp_Year=0xFFFF, Tmp_Month=0xFF, Tmp_Date=0xFF;
  u32 LeapY, ComY, TotSeconds, TotDays;
  u32 Tmp_HH = 0xFF, Tmp_MM = 0xFF, Tmp_SS = 0xFF;
  
  Tmp_Year = RTCinfo[0]*10 + RTCinfo[1];
  Tmp_Month = RTCinfo[2]*10 + RTCinfo[3];
  Tmp_Date = RTCinfo[4]*10 + RTCinfo[5];
  Tmp_HH = RTCinfo[6]*10 + RTCinfo[7];
  Tmp_MM = RTCinfo[8]*10 + RTCinfo[9];
  Tmp_SS = RTCinfo[10]*10 + RTCinfo[11];
#if 1
  {
  /* change Year-Month-Data-Hour-Minute-Seconds into X(Second) to set RTC->CNTR */
    if(Tmp_Year==00)
      LeapY = 0;
    else
      LeapY = (Tmp_Year - 00 -1)/4 +1;
    
  ComY = (Tmp_Year - 00)-(LeapY);
  
  if (Tmp_Year%4)
    //common year
    TotDays = LeapY*366 + ComY*365 + Month_Days_Accu_C[Tmp_Month-1] + (Tmp_Date-1); 
  else
    //leap year
    TotDays = LeapY*366 + ComY*365 + Month_Days_Accu_L[Tmp_Month-1] + (Tmp_Date-1); 
  
  TotSeconds = TotDays*SecsPerDay + (Tmp_HH*3600 + Tmp_MM*60 + Tmp_SS);
  }
#endif
  
  return TotSeconds;
}
vu32 TimeDisplay = 0;

void Time_Show(void)
{
  while (1)
  {
    /* If 1s has paased */
    if(TimeDisplay == 1)
    {    
      /* Display current time */
      Time_Display(RTC_GetCounter());
      TimeDisplay = 0;
    }
  }
}

#define SecsPerComYear  3153600//(365*3600*24)
#define SecsPerLeapYear 31622400//(366*3600*24)
#define SecsPerFourYear 126230400//((365*3600*24)*3+(366*3600*24))
#define SecsPerDay      (3600*24)

s32 Year_Secs_Accu[5]={0,
                      31622400,
                      63158400,
                      94694400,
                      126230400};

s32 Month_Secs_Accu_C[13] = { 0,
                            2678400,
                            5097600,
                            7776000,
                            10368000,
                            13046400,
                            15638400,
                            18316800,
                            20995200,
                            23587200,
                            26265600,
                            28857600,
                            31536000};
s32 Month_Secs_Accu_L[13] = {0,
                            2678400,
                            5184000,
                            7862400,  
                            10454400,
                            13132800,
                            15724800,
                            18403200,
                            21081600,
                            23673600,
                            26352000,
                            28944000,
                            31622400};
/**
  * @brief  Display calendar information on LCD 
  * @param  total number of seconds from RTC counter
  * @retval total number of seconds
  */
void Time_Display(u32 TimeVar)
{

  u32 TY = 0, TM = 1, TD = 0;
  s32 Num4Y,NumY, OffSec, Off4Y = 0;
  u32 i;
  s32 NumDay;
  u32 THH = 0, TMM = 0, TSS = 0;

  {
    Num4Y = TimeVar/SecsPerFourYear;
    OffSec = TimeVar%SecsPerFourYear;

    i=1;
    while(OffSec > Year_Secs_Accu[i++])
      Off4Y++;
  
    /* Numer of Complete Year */
    NumY = Num4Y*4 + Off4Y;
      /* 2000,2001,...~2000+NumY-1 complete year before, so this year is 2000+NumY*/
    TY = 00+NumY;
    
    OffSec = OffSec - Year_Secs_Accu[i-2];
    
    /* Month (TBD with OffSec)*/
    i=0;
    if(TY%4)
    {// common year
      while(OffSec > Month_Secs_Accu_C[i++]);
      TM = i-1;
      OffSec = OffSec - Month_Secs_Accu_C[i-2];
    }
    else
    {// leap year
      while(OffSec > Month_Secs_Accu_L[i++]);
      TM = i-1;
      OffSec = OffSec - Month_Secs_Accu_L[i-2];
    }
    
    /* Date (TBD with OffSec) */
    NumDay = OffSec/SecsPerDay;
    OffSec = OffSec%SecsPerDay;
    TD = NumDay+1;

      /* Compute  hours */
  THH = OffSec/3600;
  /* Compute minutes */
  TMM = (OffSec % 3600)/60;
  /* Compute seconds */
  TSS = (OffSec % 3600)% 60;
  }
  
  /* _ _�� _ _�� _ _�� */
  LCD_DrawChar(2, 0, TY/10);
  LCD_DrawChar(2, 8, TY%10);

  LCD_DrawChar(2, 32, TM/10);
  LCD_DrawChar(2, 40, TM%10);
  
  LCD_DrawChar(2, 64, TD/10);
  LCD_DrawChar(2, 72, TD%10);
  /* _ _ʱ _ _�� _ _�� */
  LCD_DrawChar(4, 0, THH/10);
  LCD_DrawChar(4, 8, THH%10);

  LCD_DrawChar(4, 32, TMM/10);
  LCD_DrawChar(4, 40, TMM%10);
  
  LCD_DrawChar(4, 64, TSS/10);
  LCD_DrawChar(4, 72, TSS%10);
}
/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
