/**
  ******************************************************************************
  * @file    main.c 
  * @author  MCU Shanghai Team
  * @version V3.1.0
  * @date    08/19/2009
  * @brief   
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "hw_config.h"
#include "lcd.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/



/**
  * @brief  Main routine.
  * @param  None
  * @retval None
  */
int main(void)
{

#ifdef DEBUG
  debug();
#endif 
  /* set system clock and initialize LCD */
  Set_System();
  /* config exti on joystick */
  JoyStick_Init(); 
  /* cnofig interrupt used : RTC and EXTI */
  Interrupts_Config();
  /* initialize GPIO for LED */
  LedGPIO_Init();
    
  /* enable access to backup domain */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
  PWR_BackupAccessCmd(ENABLE);
  /* check flag in backup domain */
  if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)
  {
    /* show menu to input initial time */
    LCD_Menu1();
    /* wait user to complete inputing and disable EXT interrupt */
    while(cursor_index < 12);
    DIS_EXTI();
    /* configure STM32 RTC IP and set LD6 on*/
    RTC_Configuration();
    GPIO_SetBits(GPIOF, GPIO_Pin_7);
    /* set RTC counter according to user input and set LD7 on*/
    Time_Adjust();
    GPIO_SetBits(GPIOF, GPIO_Pin_8);
    /* mark in backup domain */
    BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
  }
  else
  {
    LCD_Menu2();
    /* Wait for RTC registers synchronization */
    RTC_WaitForSynchro();
    /* Enable the RTC Second */
    RTC_ITConfig(RTC_IT_SEC, ENABLE);
    /* Wait until last write operation on RTC registers has finished */
    RTC_WaitForLastTask();
  }
      
  RCC_ClearFlag();
  Time_Show();
}

#ifdef  DEBUG
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  - file: pointer to the source file name
  *         - line: assert_param error line source number
  * @retval None
  */
void assert_failed(u8* file, u32 line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
