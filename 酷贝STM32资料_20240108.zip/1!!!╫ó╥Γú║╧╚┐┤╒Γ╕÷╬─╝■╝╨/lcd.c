#include "main.h"
#include "Font_Lib.h"	 	//�ֿ��ļ���
#include "123.h"	 			//�ֿ��ļ���

	//�ػ�����־
	u8 guanbi = 0;

/*****************************************************************************
** ��������:LCD_GPIOConfig
** ��������: LCD GPIO��ʼ��
**����:��
*****************************************************************************/
void LCD_GPIOConfig(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE , ENABLE); 
						 
/*********************GPIO For the LCD_Bus=***********************/	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_AF_PP;
  GPIO_Init(GPIOE, &GPIO_InitStructure);

/************************************************************	
 *	PC9 -> LCD_RESET
 *	PC8 -> Light
 *	PD4	-> RD	,	PD5	-> WR 
 *	PD7	-> CS	,	PD11 -> RS 
 **********************************************************/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 |GPIO_Pin_5 | GPIO_Pin_7 | GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_AF_PP; 	 
  GPIO_Init(GPIOD, &GPIO_InitStructure); 

}

/*****************************************************************************
** ��������:FSMC_LCD_Init
** ��������: LCD FSMC��ʼ��
**����:��
*****************************************************************************/
void FSMC_LCD_Init(void)
{
	FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
	FSMC_NORSRAMTimingInitTypeDef  FSMC_TimingInitStructure;
	/* Enable the FSMC Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);  

  FSMC_TimingInitStructure.FSMC_AddressSetupTime = 0x02;
  FSMC_TimingInitStructure.FSMC_AddressHoldTime = 0x00;
  FSMC_TimingInitStructure.FSMC_DataSetupTime = 0x05;
  FSMC_TimingInitStructure.FSMC_BusTurnAroundDuration = 0x00;
  FSMC_TimingInitStructure.FSMC_CLKDivision = 0x00;
  FSMC_TimingInitStructure.FSMC_DataLatency = 0x00;
  FSMC_TimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_B;

  FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
  FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
  FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_NOR;
  FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
  FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
  FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
  FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;	//  �洢��дʹ��
  FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;		// ��дʹ�ò�ͬ��ʱ��
  FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &FSMC_TimingInitStructure;
  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &FSMC_TimingInitStructure;	  

  FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); //	��ʼ��FSMC����
  FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE); //	ʹ��BANK1 
}


/*****************************************************************************
** ��������:LCD_WriteRAM
** ��������: д���ݵ�GRAM
**����:val
*****************************************************************************/
void LCD_WriteRAM(unsigned int val)
{
	*(volatile uint16_t *)(LCD_Data_Addr) = val;
}
/*****************************************************************************
** ��������:LCD_WriteCmd
** ��������: д�����Ĵ���
**����:index
*****************************************************************************/
void LCD_WriteCmd(unsigned int index)
{
	*(volatile uint16_t *)(LCD_Reg_Addr) = index;
}

/*****************************************************************************
** ��������:LCD_WriteReg
** ��������: ��ָ���Ĵ���дֵ
**����:LCD_Reg��LCD_RegValue
*****************************************************************************/
void LCD_WriteReg(unsigned int LCD_Reg, unsigned int LCD_RegValue)
{
	*(volatile uint16_t *) (LCD_Reg_Addr) = LCD_Reg;
	*(volatile uint16_t *) (LCD_Data_Addr) = LCD_RegValue;
}
/*****************************************************************************
** ��������:LCD_WriteRAM_Prepare
** ��������: д����׼��
**����:��
*****************************************************************************/
void LCD_WriteRAM_Prepare(void)   
{
	LCD_WrCom(0x002c);
}
/*****************************************************************************
** ��������:LCD_SetCursor
** ��������: �趨�����
**����:Xpos��Ypos
*****************************************************************************/
void LCD_SetCursor(u16 Xpos, u16 Ypos)
{
	LCD_WriteCmd(0x002A);
	LCD_WriteRAM(Xpos>>8);
	LCD_WriteRAM(Xpos);
	LCD_WriteCmd(0x002B);
	LCD_WriteRAM(Ypos>>8);
	LCD_WriteRAM(Ypos);
}
/*****************************************************************************
** ��������:LCD_Set_Window
** ��������: �趨����
**����:X1,y1,x2,y2
*****************************************************************************/
void LCD_Set_Window(u16 x1,u16 y1,u16 x2,u16 y2)
{

	LCD_WriteCmd(0x002A);
	LCD_WriteRAM(x1>>8);//X��ʼ��ַ
	LCD_WriteRAM(x1);
	LCD_WriteRAM(x2>>8);//X������ַ
	LCD_WriteRAM(x2);//X������ַ

  LCD_WriteCmd(0x002B);
	LCD_WriteRAM(y1>>8);//Y��ʼ��ַ
	LCD_WriteRAM(y1);
	LCD_WriteRAM(y2>>8);//Y������ַ
	LCD_WriteRAM(y2);
}


/*******************************************************************************
//����
//x:0~239
//y:0~399
//RGB_Code:�˵����ɫ
*******************************************************************************/
void LCD_DrawPoint(unsigned short Xpos,unsigned short Ypos,unsigned short RGB_Code)
{
  LCD_SetCursor(Xpos,Ypos);
	///LCD_WriteReg(0x002c,RGB_Code);	
	LCD_WriteRAM_Prepare();//дRAM׼��
  LCD_WriteRAM(RGB_Code);//������ɫ
}
/*******************************************************************************
//����
//x1,y1:�������
//x2,y2:�յ����� 
*******************************************************************************/
void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2,u16 RGB_Code)
{
	u16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 

	delta_x=x2-x1; //������������ 
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; //���õ������� 
	else if(delta_x==0)incx=0;//��ֱ�� 
	else {incx=-1;delta_x=-delta_x;} 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0;//ˮƽ�� 
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; //ѡȡ�������������� 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )//������� 
	{  
		LCD_DrawPoint(uRow,uCol,RGB_Code);//���� 
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
}    

/*****************************************************************************
** ��������: Draw_Circle
** ��������: ��ָ��λ�û�һ��ָ����С��Բ
//(x,y):���ĵ�
//r    :�뾶
*****************************************************************************/
void Draw_Circle(u16 x0,u16 y0,u8 r,u16 RGB_Code)
{
	int a,b;
	int di;
	a=0;b=r;	  
	di=3-(r<<1);             //�ж��¸���λ�õı�־
	while(a<=b)
		{
			LCD_DrawPoint(x0-b,y0-a,RGB_Code);             //3           
			LCD_DrawPoint(x0+b,y0-a,RGB_Code);             //0           
			LCD_DrawPoint(x0-a,y0+b,RGB_Code);             //1       
			LCD_DrawPoint(x0-b,y0-a,RGB_Code);             //7           
			LCD_DrawPoint(x0-a,y0-b,RGB_Code);             //2             
			LCD_DrawPoint(x0+b,y0+a,RGB_Code);             //4               
			LCD_DrawPoint(x0+a,y0-b,RGB_Code);             //5
			LCD_DrawPoint(x0+a,y0+b,RGB_Code);             //6 
			LCD_DrawPoint(x0-b,y0+a,RGB_Code);             
			a++;
			//ʹ��Bresenham�㷨��Բ     
			if(di<0)di +=4*a+6;	  
			else
				{
					di+=10+4*(a-b);   
					b--;
				} 
			LCD_DrawPoint(x0+a,y0+b,RGB_Code);
		}
} 
/*****************************************************************************
** ��������: LCD_DrawRectangle
** ��������: ������
*****************************************************************************/

void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2,u16 RGB_Code)
{
	LCD_DrawLine(x1,y1,x2,y1,RGB_Code);
	LCD_DrawLine(x1,y1,x1,y2,RGB_Code);
	LCD_DrawLine(x1,y2,x2,y2,RGB_Code);
	LCD_DrawLine(x2,y1,x2,y2,RGB_Code);
}

//��ָ�����������ָ����ɫ��			 
//(sx,sy),(ex,ey):�����ζԽ�����,�����СΪ:(ex-sx+1)*(ey-sy+1)   
//color:Ҫ������ɫ
void LCD_Color_FillColor(u16 sx,u16 sy,u16 ex,u16 ey,u16 color)
{  
	u16 i,t;
	
	t = (ex-sx+1)*(ey-sy+1);
	LCD_Set_Window(sx,sy,ex,ey);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM
	for(i=0;i<t;i++)
		{
			LCD_WriteRAM(color);//д������ 
		}
}  


//��ָ�����������ָ����ɫ��			 
//(sx,sy),(ex,ey):�����ζԽ�����,�����СΪ:(ex-sx+1)*(ey-sy+1)   
//color:Ҫ������ɫ
void LCD_Color_Fill(u16 sx,u16 sy,u16 ex,u16 ey,u16 *color)
{  
	u16 i,t;
	
	t = (ex-sx+1)*(ey-sy+1);
	LCD_Set_Window(sx,sy,ex,ey);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM
	for(i=0;i<t;i++)
		{
			LCD_WriteRAM(color[i]);//д������ 
		}
}  

/*****************************************************************************
** ��������: WriteOneASCII
** ��������: ��ʾһ��ָ����С���ַ�
*****************************************************************************/
u16 WriteOneASCII(u8 *pucMsk, u16 x0, u16 y0, u16 color, u16 back_color)
{
	u16 i,j;
	u16 y;
	u8 ucChar;

	y = y0;
	for(i=0; i<16; i++)  														// 16�� 
		{                                 						// 16�� 
			ucChar = *pucMsk++;
			#ifdef __DISPLAY_BUFFER                     // ʹ���Դ���ʾ
			for(j=0; j<8; j++)  												// 8�� 
				{                             
					if((ucChar << j)& 0x80)                 // ��ʾ��ģ 
						{
							DispBuf[240*(y0+i) + x0+j] = color;
						}
				}
			#else                                       // ֱ����ʾ
			LCD_Set_Window(x0,y,x0+16,y+16);          	// ����д���ݵ�ַָ�� 
			LCD_WriteRAM_Prepare();        					  	// ��ʼд��GRAM
			for(j=0; j<8; j++) 													// 8�� 
				{                     
					if((ucChar << j) & 0x80)								// ��ʾ��ģ 
						{ 
							LCD_WriteRAM(color);
						} 
					else 
						{
							LCD_WriteRAM(back_color);
						}
				}
			y++;
			#endif
		}
	return (8); 
}

//*****************************************************************
//���������m:����
//	        n:��
//����ֵ��  m��n�η�
//�޸ļ�¼����
//******************************************************************  
u32 mypow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}	 

//num:���ݷ�Χ(0~4294967295);	 
void LCD_ShowxNum(u16 x,u16 y,u32 num,u8 len, u16 color, u16 back_color)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/mypow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				WriteOneASCII((u8 *)&ASCII_1608[('0' - 0x20)][0],x + 8*t, y, color,back_color);
				continue;
			}else enshow=1;	 
		}
		WriteOneASCII((u8 *)&ASCII_1608[(temp + '0' - 0x20)][0],x + 8*t, y, color,back_color);
	}
} 

void WriteOneDigitalTube(u16 x0, u16 y0,u8 num, u16 color, u16 back_color)
{
	u16 i,j;
	LCD_Set_Window(x0,y0,x0+23,y0+34);          	// ����д���ݵ�ַָ�� 
	LCD_WriteRAM_Prepare();        					  	// ��ʼд��GRAM
	for(i=0;i<105;i++) 												
		{
			for(j=0; j<8; j++)                           // 16�� 
				{
					if(((DigitalTube[num][i] << j)&0x80) == 0x80)
						{
							if(((DigitalTube[8][i] << j)&0x80) == 0x80)
								{
									LCD_WriteRAM(back_color);
								}
							else
								{
									LCD_WriteRAM(0xF7BE);
								}
						}
					else
						{
							LCD_WriteRAM(color);
						}
				}
		}
}


//num:���ݷ�Χ(0~4294967295);	 
void LCD_DigitalTubeNum(u16 x,u16 y,u32 num,u8 len, u16 color, u16 back_color)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
		{
			temp=(num/mypow(10,len-t-1))%10;
			if(enshow==0&&t<(len-1))
				{
					if(temp==0)
						{
							WriteOneDigitalTube(x + 24*t,y,temp,color,back_color);
							continue;
						}else enshow=1;	 
				}
			WriteOneDigitalTube(x + 24*t,y,temp,color,back_color);
		}
} 


void LCD_DigitalTubePassNum(u16 x,u16 y,u32 num,u8 len, u16 color, u16 back_color)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
		{
			temp=(num/mypow(10,len-t-1))%10;
			if(enshow==0&&t<(len-1))
				{
					if(temp==0)
						{
							WriteOneDigitalTube(x + 24*t,y,10,color,back_color);
							continue;
						}else enshow=1;	 
				}
			WriteOneDigitalTube(x + 24*t,y,10,color,back_color);
		}
} 


/*****************************************************************************
** ��������: WriteOneHzChar
** ��������: ��ʾһ��ָ����С�ĺ���
*****************************************************************************/
u16 WriteOneHzChar(u8 *pucMsk, u16 x0, u16 y0, u16 color, u16 back_color)
{
	u16 i,j;
	u16 mod[16];                                    	// ��ǰ��ģ    
	u16 *pusMsk;                                      // ��ǰ�ֿ��ַ 
	u16 y;

	pusMsk = (u16 *)pucMsk;
	for(i=0; i<16; i++)                               // ���浱ǰ���ֵ���ʽ��ģ 
		{
			mod[i] = *pusMsk++;                           // ȡ�õ�ǰ��ģ�����ֶ������
			mod[i] = ((mod[i] & 0xff00) >> 8) | ((mod[i] & 0x00ff) << 8); // ��ģ�����ߵ��ֽ� Ϊ����ʾ��Ҫ 
		}
	y = y0;
	for(i=0; i<16; i++)                               // 16�� 
		{ 
			#ifdef __DISPLAY_BUFFER                       // ʹ���Դ���ʾ
			for(j=0; j<16; j++)                           // 16�� 
				{
				if((mod[i] << j)& 0x8000)                   // ��ʾ��ģ  
					{
						DispBuf[240*(y0+i) + x0+j] = color;
					}
				}
			#else
			LCD_Set_Window(x0, y,x0+16,y+16);            // ����д���ݵ�ַָ�� 
			LCD_WriteRAM_Prepare();        					   	 // ��ʼд��GRAM
			for(j=0; j<16; j++)                          // 16�� 
				{
					if((mod[i] << j) & 0x8000)               // ��ʾ��ģ 
						{ 
							LCD_WriteRAM(color);
						} 
					else 
						{
							LCD_WriteRAM(back_color);            // �ö���ʽ����д�հ׵������
						}
				}
			y++;
			#endif
	}
	return (16);                                     // ����16λ�п� 
}


u16 findHzIndex(u8 *hz)                     /* ���Զ��庺�ֿ��ڲ�����Ҫ��ʾ *//* �ĺ��ֵ�λ�� */
{
	u16 i=0;
	FNT_GB16 *ptGb16 = (FNT_GB16 *)GBHZ_16;
	while(ptGb16[i].Index[0] > 0x80) 
		{
			if ((*hz == ptGb16[i].Index[0]) && (*(hz+1) == ptGb16[i].Index[1])) 
				{
					return i;
				}
			i++;
			if(i > (u16)(sizeof((FNT_GB16 *)GBHZ_16) / sizeof(FNT_GB16) - 1))  /* �����±�Լ�� */
				{
					break;
				}
		}
	return 0;
}


/*****************************************************************************
** ��������: LCD_ShowString
** ��������: ��ָ��λ�ÿ�ʼ��ʾһ���ַ�����һ������
				֧���Զ�����
*****************************************************************************/   			   
void LCD_ShowString(u16 x0, u16 y0,u8 *pcStr, u16 color,u16 back_color)
{
	u16 usIndex;
	u16 usWidth = 0;
	FNT_GB16 *ptGb16 = 0;

	ptGb16 = (FNT_GB16 *)GBHZ_16;  
	while(1)
		{
			if(*pcStr == 0) 
				{
					break;                                     /* �ַ�������            */
				}      
			x0 = x0 + (usWidth);                           /* �����ַ�����ʾ�ɽ���         */
			if(*pcStr > 0x80)                              /* �ж�Ϊ����                   */
				{
					if((x0 + 16) > LCD_W)                      /* ���ʣ��ռ��Ƿ��㹻         */
						{
							x0 = 0;
							y0 = y0 + 16;                          /* �ı���ʾ����                 */
							if(y0 > LCD_H)                         /* �����곬��                   */
								{
									y0 = 0;
								}
						}
					usIndex = findHzIndex(pcStr);
					usWidth = WriteOneHzChar((u8 *)&(ptGb16[usIndex].Msk[0]), x0, y0, color,back_color) + 1;
					/* ��ʾ�ַ�  */
					pcStr += 2;
				}
			else 
				{                                           /* �ж�Ϊ�Ǻ���                 */
				if (*pcStr == '\r')                         /* ����                         */
					{ 
						y0 = y0 + 16;                           /* �ı���ʾ����                 */
						if(y0 > LCD_H)                          /* �����곬��                   */
							{
								y0 = 0;
							}
						pcStr++;
						usWidth = 0;
						continue;
					} 
				else if (*pcStr == '\n')                    /* ���뵽���                   */
					{
						x0 = 0;
						pcStr++;
						usWidth = 0;
						continue;
					} 
				else 
					{
						if((x0 + 8) > LCD_W)                     /* ���ʣ��ռ��Ƿ��㹻         */
							{
								x0 = 0;
								y0 = y0 + 16;                        /* �ı���ʾ����                 */
								if(y0 > LCD_H)                       /* �����곬��                   */
									{ 
										y0 = 0;
									}
							}
						usWidth = WriteOneASCII((u8 *)&ASCII_1608[(*pcStr - 0x20)][0], x0, y0, color,back_color);
						/* ASCII���21H��ֵ��Ӧ��λ��3��*/
						pcStr += 1;
					}
			 }
		}												  	  
}
/*****************************************************************************
** ��������:LCD_Clear
** ��������: ����
**����:Color
Made by Mleaf_HEXI
ʱ�䣺2012 08 25
*****************************************************************************/

void LCD_Clear(u16 Color)                  
{	
	u32 index=0; 
	LCD_Set_Window(0,0,320,240);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(index=0;index<76800;index++)
		{
			LCD_WriteRAM(Color);
		}
}


/*****************************************************************************
** ��������: LCD_Init
** ��������: ��ʼ��ILI9327
Made by mleaf_hx
*****************************************************************************/ 
void LCD_Init(void)
{
	FSMC_LCD_Init();
	LCD_GPIOConfig();

	LCD_REST=1;
	delay_ms(50);
	LCD_REST=0;
	delay_ms(10);
	LCD_REST=1;
	delay_ms(10);

	LCD_WrCom(0x00e9);
	LCD_WrDat(0x0020);     //Exit_invert_mode
	LCD_WrCom(0x0011);     //Exit_sleep_mode 
	delay_ms(100);

	LCD_WrCom(0x00d1);
	LCD_WrDat(0x0000);
	LCD_WrDat(0x0071);
	LCD_WrDat(0x0019);

	LCD_WrCom(0x00d0);
	LCD_WrDat(0x0007);
	LCD_WrDat(0x0001);
	LCD_WrDat(0x0008);

	LCD_WrCom(0x0036);  //Set_address_mode ��ʾ����
	LCD_WrDat(0x00E8);  //�������� �������� 

	LCD_WrCom(0x003a);  //Set_pixel_format
	LCD_WrDat(0x0005);  //DBI 65K colors

	LCD_WrCom(0x00C1);
	LCD_WrDat(0x0010);
	LCD_WrDat(0x0010);
	LCD_WrDat(0x0002);
	LCD_WrDat(0x0002);

	LCD_WrCom(0x00C0);//Set Default Gamma
	LCD_WrDat(0x0000);
	LCD_WrDat(0x0035);
	LCD_WrDat(0x0000);
	LCD_WrDat(0x0000);
	LCD_WrDat(0x0001);
	LCD_WrDat(0x0002);

	LCD_WrCom(0x00C5); //Set frame rate
	LCD_WrDat(0x0004);

	LCD_WrCom(0x00D2); //power setting
	LCD_WrDat(0x0001);
	LCD_WrDat(0x0044);

	LCD_WrCom(0x00C8); //Set Gamma
	LCD_WrDat(0x0004);
	LCD_WrDat(0x0067);
	LCD_WrDat(0x0035);
	LCD_WrDat(0x0004);
	LCD_WrDat(0x0008);
	LCD_WrDat(0x0006);
	LCD_WrDat(0x0024);
	LCD_WrDat(0x0001);
	LCD_WrDat(0x0037);
	LCD_WrDat(0x0040);
	LCD_WrDat(0x0003);
	LCD_WrDat(0x0010);
	LCD_WrDat(0x0008);
	LCD_WrDat(0x0080);
	LCD_WrDat(0x0000);

	LCD_WrCom(0x002A);//Set_column_address
	LCD_WrDat(0x0000);                
	LCD_WrDat(0x0000); //x1 =   0
	LCD_WrDat(0x0000);
	LCD_WrDat(0x00ef); //x2 = 239

	LCD_WrCom(0x002b); //Set_page_address
	LCD_WrDat(0x0000);
	LCD_WrDat(0x0000); //y1 =   0
	LCD_WrDat(0x0001);
	LCD_WrDat(0x008f); //y2 = 399

	LCD_WrCom(0x0029); //display on
	LCD_WrCom(0x002C); //write_memory_start
	LCD_LIGHT_ON;//���������



	LCD_Clear(White);//����

}

/* ��ʾ���״̬ */
void Battery_Status(u8 voltage)
{
	u16 i;

	if(voltage == 5)
		{
			/* ��ʾ�����Դ */
			LCD_Set_Window(290,7,292,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(294,7,296,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(298,7,300,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(302,7,304,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(306,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
		}
	else if(voltage == 4)
		{
			/* �����ʾ */
			LCD_Set_Window(290,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<133;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
				
			/* ȱ 1 ��� */
			LCD_Set_Window(290,7,292,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(294,7,296,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(298,7,300,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(302,7,304,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
		}
	else if(voltage == 3)
		{
			/* �����ʾ */
			LCD_Set_Window(290,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<133;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
				
			/* ȱ 1 ��� */
			LCD_Set_Window(290,7,292,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(294,7,296,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(298,7,300,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
		}
	else if(voltage == 2)
		{
			/* �����ʾ */
			LCD_Set_Window(290,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<133;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
				
			/* ȱ 1 ��� */
			LCD_Set_Window(290,7,292,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
			LCD_Set_Window(294,7,296,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
		}
	else if(voltage == 1)
		{
			/* �����ʾ */
			LCD_Set_Window(290,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<133;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
				
			/* ȱ 1 ��� */
			LCD_Set_Window(290,7,292,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<21;i++)
				{
					LCD_WriteRAM(0x0000);
				}
		}
	else
		{
			/* �ո��Դ */
			LCD_Set_Window(290,7,308,13);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<133;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
		}
}

/* ��ʾ���״̬ */
void Battery_Charging(u8 model)
{
	u8 i;
	if(model == 1)
		{
			//��ʾ�յ��״̬
			LCD_Set_Window(278,6,282,14);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<45;i++)
				{
					LCD_WriteRAM((BatteryCharging[2*i]<<8) + BatteryCharging[2*i + 1]);
				}
		}
	else
		{
			//��ʾ�յ��״̬
			LCD_Set_Window(278,6,282,14);
			LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
			for(i=0;i<45;i++)
				{
					LCD_WriteRAM(0xFFFF);
				}
		}
}

//��ʾ��ͷ
void Arrow_According(u16 x,u16 y,u8 Arrowbit, u16 color,u16 back_color)
{
	u8 i,j;
	LCD_Set_Window(x,y,x+15,y+14);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(i=0;i<30;i++)
		{
			for(j=0;j<8;j++)
				{
					if(Arrowbit == 0)
						{
							LCD_WriteRAM(back_color);
						}
					else
						{
							if((ArrowBuff[i] << j) & 0x80)								// ��ʾ��ģ 
								{
									LCD_WriteRAM(color);
								} 
							else 
								{
									LCD_WriteRAM(back_color);
								}
						}
				}
		}
}


/* ��ʾ���� */
void LCD_Update_Display(void)
{
	//����ʱ��
	if(LCD.UpdateTimeBit == 1)
		{
			LCD.UpdateTimeBit = 0;
			//����ʱ��
			LCD_DisplayTime(0);
		}
	//���µ��״̬
	if(LCD.UpdateVolBit == 1)
		{
			LCD.UpdateVolBit = 0;
			//���µ��״̬
			Get_ADC_POWER();
		}
		
}

//��ʾ ʱ�� �� ��ص���
void LCD_Start(void)
{
	u8 i,j;
	//��ʾʱ��
	LCD_ShowString(100,3,(u8 *)"0000-00-00 00:00",BLACK,White);
	
	//��ʾ�յ��״̬
	LCD_Set_Window(288,5,319,15);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(i=0;i<44;i++)
		{
			for(j=0;j<8;j++)
				{
					if((BatteryEmpty[i] << j) & 0x80)								// ��ʾ��ģ 
						{ 
							LCD_WriteRAM(0xFFFF);
						} 
					else 
						{
							LCD_WriteRAM(0x0000);
						}
				}
		}
}

//��ʼ�� ��ҳ�沼��
void LCD_Main_Page(void)
{
	u32 y;
	u8 ch[8];
	//�����Ż���
	LCD_ShowString(10,3,(u8 *)"   ",Red,White);
	
	/* ǿ����ʾ ʱ�� */
	LCD_DisplayTime(1);
	
	//ˢ�� ��� ��ʾ���״̬	
	LCD.UpdateVolNum = 0;
	Get_ADC_POWER();
		
	//���������ʾ
	LCD_Set_Window(0,20,319,239);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(y=0;y<70400;y++)
		{
			LCD_WriteRAM(0xFFFF);	
		}
	
	//��ʾ ͼ��
	LCD_Set_Window(13,55,140,177);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(y=0;y<15744;y++)
		{
			LCD_WriteRAM((gImage_123[y*2]<<8)+gImage_123[y*2 + 1]);	
		}

	//����Ա
	LCD_ShowString(155,45,(u8 *)"����Ա",BROWN,White);
	LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
	//Ĭ���û���
	LCD_DigitalTubeNum(155+24*3,70,0,3,BLACK,0xFFFF);
	//ȷ������		
	LCD_ShowString(155,115,(u8 *)"������",BROWN,White);
	LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
	//��ʾ��ͷ
	Arrow_According(300,150,1,BLACK,White);
		
	//��ʾ��¼
	LCD_ShowString(275,215,(u8 *)"��¼",DARKBLUE,White);
		
	//��ʾ��ǰ ����汾  	char *ch = "V_0.0.0";
	ch[0] = 'v';
	ch[1] = '_';
	ch[2] = (Work.Version/100 + 0x30);
	ch[3] = '.';
	ch[4] = ((Work.Version/10)%10 + 0x30);
	ch[5] = '.';
	ch[6] = (Work.Version%10 + 0x30);
	ch[7] = 0;
	LCD_ShowString(10,215,ch,DARKBLUE,White);

}

//�л� ����ģʽ
void Arrow_Switch(void)
{

}


//�򵥹ػ����� 
void guanji(void)
{
	//ѭ���ж� �ػ�
	u8 time = 0;
	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_1) == 1)
		{
			if(guanbi == 1)
				{
					do
					{
						delay_ms(5);
						time++;
						if(time >= 100)
							{
								//�ر�USB 
								GPIO_ResetBits(GPIOA,GPIO_Pin_8);
								//�ص�
								GPIO_ResetBits(GPIOE,GPIO_Pin_0);
							}
					}while(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_1) == 1);
				}
		}
	else
		{
			//�ſ������� 
			guanbi = 1;
		}
}



/* ��ʾ������ */
u8 LCD_Page1(void)
{
	u8 key = 0;

	//ҳ��1 ����
	u8 PageMode;						//ҳ��Ĭ�ϲ���
	u8 CashierCache[3];			//����Ա����
	u8 CashierLen;					//����Ա���볤��
	u8 CashierNumber;				//����Ա �������
	u8 PasswordCache[6];		//�����ֻ���	
	u8 PasswordLen;					//�������볤��
	
	//������Ա
	CashierNumber = 0;
	CashierLen = 3;
	CashierCache[0] = 0x30;
	CashierCache[1] = 0x30;
	CashierCache[2] = 0x30;
	//ѡ�� ������
	PageMode = 2;
	//�������� ��ֵ
	PasswordLen = 0;
	PasswordCache[0] = 0;
	PasswordCache[1] = 0;
	PasswordCache[2] = 0;
	PasswordCache[3] = 0;
	PasswordCache[4] = 0;
	PasswordCache[5] = 0;

	//��ʼ��������
	LCD_Main_Page();
	while(1)
		{
			
			//�򵥹ػ����� 
			guanji();
			
			/* ��ʱ�ȴ� */
			delay_ms(5);
			
			//����ģʽ
			if(Work.Dormancy == 0)
				{
					/* ��ʾ���� */
					LCD_Update_Display();
				}
			/* �������� */
			key = KEY_Scan(0);
			if(key)
				{
					//�ر�����ģʽ
					Work.Dormancy  = 0;
					
					switch(key)
						{				 
							case 1:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x31;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x31;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x31;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x31;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x31;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x31;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();

												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 2:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x32;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x32;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x31;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x32;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x32;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x32;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 3:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x33;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x33;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x33;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x33;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x33;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x33;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 4:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x34;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x34;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x34;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x34;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x34;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x34;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 5:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x35;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x35;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x35;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x35;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x35;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x35;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 6:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x36;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x36;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x36;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x36;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x36;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x36;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
														return 6;
													}
											}
									}
								break;
							case 7:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x37;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x37;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x37;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x37;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x37;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x37;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;	
							case 8:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x38;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x38;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x38;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x38;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x38;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x38;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 9:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x39;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x39;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x39;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x39;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x39;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x39;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 11:
								if(PageMode == 1)
									{
										//��������Ա ���
										if(CashierLen == 2)
											{
												CashierLen = 3;
												
												//ѡ�� ������
												PageMode = 2;
												//��ʾ ����ֵ
												CashierCache[2] = 0x30;
												LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
												//��� ��������ʾ��ͷ
												Arrow_According(300,150,1,BLACK,White);
												//��ʾ ѡ������Ա
												Arrow_According(300,80,0,BLACK,White);
												//�л�����
												BEEP_1kHZ();
											}
										else if(CashierLen >= 3)
											{
												/* ��һ�γ��������ֽ� �������� */
												if(CashierNumber == 0)
													{
														CashierCache[0] = 0x30;
														CashierCache[1] = 0;
														CashierCache[2] = 0;
														CashierLen = 1;
														CashierNumber = 1;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(6-CashierLen),70,CashierCache[0]-0x30,CashierLen,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else
													{
														//ѡ�� ������
														PageMode = 2;
														//��ʾ ����ֵ
														CashierCache[2] = 0x30;
														LCD_DigitalTubeNum(155+24*(3),70,(CashierCache[0] - 0x30)*100 + (CashierCache[1] - 0x30)*10 + (CashierCache[2]- 0x30),3,BLACK,0xFFFF);
														//��� ��������ʾ��ͷ
														Arrow_According(300,150,1,BLACK,White);
														//��ʾ ѡ������Ա
														Arrow_According(300,80,0,BLACK,White);
														//�л�����
														BEEP_1kHZ();
													}
											}
										else
											{
												if(CashierLen == 0)
													{
														CashierLen	= 1;
														CashierCache[0] = 0x30;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
												else if(CashierLen == 1)
													{
														CashierLen	= 2;
														CashierCache[1] = 0x30;
														LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + (CashierCache[1]- 0x30),2,BLACK,0xFFFF);
														//�л�����
														BEEP_1kHZ();
													}
											}
									}
								else if(PageMode == 2)
									{
										//������ ����
										if(PasswordLen == 0)
											{
												PasswordLen = 1;
												PasswordCache[0] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0] - 0x30),PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 1)
											{
												PasswordLen = 2;
												PasswordCache[1] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10 + PasswordCache[1]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 2)
											{
												PasswordLen = 3;
												PasswordCache[2] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100 + (PasswordCache[1]-0x30)*10 + PasswordCache[2]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 3)
											{
												PasswordLen = 4;
												PasswordCache[3] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*1000 + (PasswordCache[1]-0x30)*100 + (PasswordCache[2]-0x30)*10 + PasswordCache[3]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 4)
											{
												PasswordLen = 5;
												PasswordCache[4] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*10000 + (PasswordCache[1]-0x30)*1000 + (PasswordCache[2]-0x30)*100 + (PasswordCache[3]-0x30)*10 + PasswordCache[4]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
											}
										else if(PasswordLen == 5)
											{
												PasswordLen = 6;
												PasswordCache[5] = 0x30;
												LCD_DigitalTubePassNum(155 + 24*(6-PasswordLen) ,140,(PasswordCache[0]-0x30)*100000 + (PasswordCache[1]-0x30)*10000 + (PasswordCache[2]-0x30)*1000 + (PasswordCache[3]-0x30)*100 + (PasswordCache[4]-0x30)*10 + PasswordCache[5]-0x30,PasswordLen,BLACK,0xFFFF);
												//�л�����
												BEEP_1kHZ();
												//�жϵ�¼�Ƿ���ȷ
												Work.CashierEmployee[0] = CashierCache[0];
												Work.CashierEmployee[1] = CashierCache[1];
												Work.CashierEmployee[2] = CashierCache[2];
												if((PasswordCache[0] == '1')&&(PasswordCache[1] == '2')&&(PasswordCache[2] == '3')&&(PasswordCache[3] == '4')&&(PasswordCache[4] == '5')&&(PasswordCache[5] == '6'))
													{
														LCD_Page2();
													}
											}
									}
								break;
							case 13: // ���� ����
									  mf_scan_files((u8 *)"0:",Work.Version);								//����Bin�ļ�
							
							
							
										
								break;
							case 18: //ֱ�����
									if(PageMode == 1)
										{
											LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
											CashierLen = 0;
											BEEP_1kHZ();
										}
									else
										{
											LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
											PasswordLen = 0;
											BEEP_1kHZ();
										}
								break;
							case 19: //������һλ
									if(PageMode == 1)
										{
											if(CashierLen >= 1)
												{
													if(CashierLen == 1)
														{
															LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
														}
													else if(CashierLen == 2)
														{
															LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubeNum(155+24*(5),70,(CashierCache[0]- 0x30),1,BLACK,0xFFFF);
														}
													else if(CashierLen == 3)
														{
															LCD_DigitalTubeNum(155,70,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubeNum(155+24*(4),70,(CashierCache[0] - 0x30)*10 + CashierCache[1] - 0x30,2,BLACK,0xFFFF);
														}
													//����һλ
													CashierLen = CashierLen - 1;
												}
											BEEP_1kHZ();
										}
									else
										{
											if(PasswordLen >= 1)
												{
													if(PasswordLen == 1)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
														}
													else if(PasswordLen == 2)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubePassNum(155+24*(5),140,(PasswordCache[0]- 0x30),1,BLACK,0xFFFF);
														}
													else if(PasswordLen == 3)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubePassNum(155+24*(4),140,(PasswordCache[0]- 0x30)*10 + PasswordCache[1]- 0x30,2,BLACK,0xFFFF);
														}
													else if(PasswordLen == 4)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubePassNum(155+24*(3),140,(PasswordCache[0]- 0x30)*100 + (PasswordCache[1]- 0x30)*10 + (PasswordCache[2]- 0x30),3,BLACK,0xFFFF);
														}
													else if(PasswordLen == 5)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubePassNum(155+24*(2),140,(PasswordCache[0]- 0x30)*1000 + (PasswordCache[1]- 0x30)*100 + (PasswordCache[2]- 0x30)*10 +(PasswordCache[3]- 0x30) ,4,BLACK,0xFFFF);
														}
													else if(PasswordLen == 6)
														{
															LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
															LCD_DigitalTubePassNum(155+24*(1),140,(PasswordCache[0]- 0x30)*10000 + (PasswordCache[1]- 0x30)*1000 + (PasswordCache[2]- 0x30)*100 +(PasswordCache[3]- 0x30)*10 + (PasswordCache[4]- 0x30) ,5,BLACK,0xFFFF);
														}
													//����һλ
													PasswordLen = PasswordLen - 1;
												}
											BEEP_1kHZ();
										}
								break;
							case 20:
								//�л� ����
								if(PageMode == 1)
									{
										if(CashierLen >= 3)
											{
													//ѡ�� ������
													PageMode = 2;

													//��� ��������ʾ��ͷ
													Arrow_According(300,150,1,BLACK,White);
													//��ʾ ѡ������Ա
													Arrow_According(300,80,0,BLACK,White);
													//��ʾ����
													BEEP_10kHZ();
											}
										else
											{
												//�л����ɹ�
												BEEP_1kHZ();
											}
									}
								else
									{
										//ѡ�� ����Ա
										PageMode = 1;
										//��� ������ ����
										PasswordLen = 0;
										//��� ������ ����
										PasswordCache[0] = 0;
										PasswordCache[1] = 0;
										PasswordCache[2] = 0;
										PasswordCache[3] = 0;
										PasswordCache[4] = 0;
										PasswordCache[5] = 0;
										//�򿪿���ѭ������
										CashierNumber = 0;
										//�����ʾ
										LCD_DigitalTubeNum(155,140,888888,6,0xF7BE,0xFFFF);
										//��� ��������ʾ��ͷ
										Arrow_According(300,150,0,BLACK,White);
										//��ʾ ѡ������Ա
										Arrow_According(300,80,1,BLACK,White);
										//��ʾ����
										BEEP_10kHZ();
									}
								break;
							default :BEEP_10kHZ();break;
						}
				}
		}
//	return 0;
}


/* �ж϶� CPU ��ָ���Ƿ�ɹ� */
u8 Cheak_90(u8 *buff,u8 len)
{
	u8 i;
	for(i=0;i<len;i++)
		{
			if(buff[i] == 0x90)return 1;
		}
	return 0;
}


/* ����Ա��¼���� */
u8 LCD_Page2(void)
{
	u8 key;
	u32 i,t;
	u16 cha[2] = {0x0000,0xFFFF};
	//IC ��  010700070108
	u8 Ikey[6]={0x01,0x07,0x00,0x07,0x01,0x08};
	//CPU ������
	u8 size;
	u8 Rand[6];
	u8 Cache[32];//����
	u8 CertificaKey[16]={0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};//�ⲿ��֤��Կ
	u8 FilePassword[8] = {0x12,0x34,0x56,0x78,0x12,0x34,0x56,0x78};
//	u8 Amount[4]={0x00,0x00,0x00,0x01};//���׽��
//	u8 TerminalNum[6] = {0x00,0x00,0x00,0x00,0x00,0x02};//�ն˻�̨��
//	u8 Time[7] = {0x20,0x19,0x12,0x17,0x16,0x20,0x20};//���׼�¼ʱ��
	
	
	//����Ա ��ŵ�¼
	LCD_ShowString(10,3,Work.CashierEmployee,Red,White);
	
	//��ʾ ͼ��
	LCD_Set_Window(0,20,319,239);
	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
	for(i=0;i<70400;i++)
		{
			LCD_WriteRAM(0xFFFF);	
		}
	
	//����1
	LCD_ShowString(50,50,(u8 *)"1: NFC_M24SR04 ",BRRED,White);
	//����2
	LCD_ShowString(50,70,(u8 *)"2: RFID_FM17522 ",BRRED,White);
	//����3
	LCD_ShowString(50,90,(u8 *)"3: Qrcode",BRRED,White);
	//����4
	LCD_ShowString(50,110,(u8 *)"4: Time",BRRED,White);
		
	//��ʾ�˳�
	LCD_ShowString(275,215,(u8 *)"�˳�",DARKBLUE,White);
		
	//LCD_DrawLine(0,0,320,240,RED);	
	//Draw_Circle(50,50,15,YELLOW);
	//LCD_DrawRectangle(50,50,80,80,BROWN);
	//LCD_ShowString(50,200,(u8 *)"HE XI",RED,BLUE);
		
	while(1)
		{
			/* ��ʱ�ȴ� */
			delay_ms(5);
			//����ģʽ
			if(Work.Dormancy == 0)
				{
					/* ��ʾ���� */
					LCD_Update_Display();
				}
			/* �������� */
			key = KEY_Scan(0);
			if(key)
				{
					switch(key)
						{				 
							case 1: 
								BEEP_10kHZ();
								//�����ʾ���� ��ʾ����
								LCD_Set_Window(50,50,269,189);
								LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
								for(i=0;i<8800;i++)
									{
										LCD_WriteRAM(0xFFFF);	
									}
								//���� д�� 
								LCD_ShowString(50,50,(u8 *)"1: Store URI in M24SR",BRRED,White);
								LCD_ShowString(50,70,(u8 *)"2: Read URI from M24SR",BRRED,White);
								LCD_ShowString(50,90,(u8 *)"3: Store SMS in M24SR ",BRRED,White);
								LCD_ShowString(50,110,(u8 *)"4: Read SMS from M24SR",BRRED,White);									
								
									
									
									
								break;
						case 2:
								//��ʼ�� SPI3 �ܽ�
								InitRc522();
								/* ��λRC522   */
								Reset_RC522();
								/* Ѱ�� */
								if(PcdRequest(PICC_REQALL,rc522.UID) == MI_OK)
									{
										if(rc522.type == 0)//IC ��
											{
												/* ����ײ */
												if(PcdAnticoll(rc522.UID) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ѡ����Ƭ */
												if(PcdSelect(rc522.UID) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ��֤�ǲ��Ǳ���˾�Ŀ� */
												if(PcdAuthState(PICC_AUTHENT1B,1,Ikey,rc522.UID) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ����0�������� ��һ�� */
												if(PcdRead(1,rc522.BlockData) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												
												//��ʾ���
												LCD_ShowString(50,150,(u8 *)"Money:",DARKBLUE,White);
												LCD_ShowxNum(50+(6*8),150,(rc522.BlockData[0]*256)+(rc522.BlockData[1]),5,DARKBLUE,White);
												
											}
										else if(rc522.type == 1)//CPU ��
											{
												/* ����ײ */
												if(PcdAnticoll(rc522.UID) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ѡ����Ƭ */
												if(PcdSelect(rc522.UID) != MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ATS 107880A00220 9000 00000000D3574F0A */	
												if(PiccRequestATS(0,rc522.Buf)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ѡ�� DF Ŀ¼�ļ� 6F07 84054444463031(DDF01) 9000 */
												Choose_DFfile();
												if(PiccTPCL(rc522.SBuf,7,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ��ȡ����� 0B01 6F187F84 9000*/
												Take_random();
												if(PiccTPCL(rc522.SBuf,5,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												if(Cheak_90(rc522.Buf,size) == 0){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												for(i=0;i<6;i++)Rand[i] = rc522.Buf[i];//���������
												/* �ⲿ��֤ 3DES���������  0A01 9000*/
												Rand3DES_encryp(Rand,CertificaKey,1);
												if(PiccTPCL(rc522.SBuf,13,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												if(Cheak_90(rc522.Buf,size) == 0){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;};
												/* ѡ�����Ǯ���ļ��� */
												Choose_binfile(0);
												if(PiccTPCL(rc522.SBuf,7,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												if(Cheak_90(rc522.Buf,size) == 0){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												/* ��֤ DF ������Կ */
												Confirm_BinPass(FilePassword);
												if(PiccTPCL(rc522.SBuf,13,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												if(Cheak_90(rc522.Buf,size) == 0){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}			
												/* ��ȡ��� */
												ReadBalance();
												if(PiccTPCL(rc522.SBuf,5,rc522.Buf,&size)!=MI_OK){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												if(Cheak_90(rc522.Buf,size) == 0){PcdHalt();PcdAntennaOff();RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );break;}
												
												//��ʾ���
												LCD_ShowString(50,150,(u8 *)"Money:",DARKBLUE,White);
												LCD_ShowxNum(50+(6*8),150,(rc522.Buf[2]*256)+(rc522.Buf[3]),5,DARKBLUE,White);
												
											}
										BEEP_1kHZ();
									}
								else
									{
										BEEP_10kHZ();
									}
								PcdHalt();
								PcdAntennaOff();   //�ر�����
								RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3,DISABLE );
								break;
							case 3:
								BEEP_10kHZ();
								//��ʾ��ά��	
								ShowQRcode("http://192.168.0.222:8999/index.html");
								for(i=0;i<LCD.QRC_Len;i++)
									{
										for(t=0;t<LCD.QRC_Len;t++)
											{
												if(LCD.QRCODE[i][t]==0x01)
													{
														LCD_Color_FillColor(4*i+200,4*t+100,4*i+200+4-1,4*t+100+4-1,cha[0]);
													}
												else 
													{
														LCD_Color_FillColor(4*i+200,4*t+100,4*i+200+4-1,4*t+100+4-1,cha[1]);
													}
											}
									}	
								break;
							case 16:
									return 0;
							case 17:
									return 0;
								break;
							default :BEEP_10kHZ();break;
						}
				}
		}
	//return 0;
}

