#ifndef __TM1668_H
#define __TM1668_H 

#include "sys.h"

u8 Read_key(void);  //������

u8 KEY_Scan(u8 mode);

#endif
