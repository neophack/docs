#include "main.h"

//����һ���ֽ�
void TM1668_Write(u8 DATA)
{
	unsigned char i;
	SDA_OUT(); 
	delay_us(2); 
	for(i=0;i<8;i++)
	{
		TM1668_CLK=0;
		delay_us(2); 
		if(DATA&0X01)
			OUT_SDA=1;
		else
			OUT_SDA=0;
		delay_us(2); 
		DATA>>=1;
		TM1668_CLK=1;
		delay_us(2); 
	}
}

//���ֽ�
u8 TM1668_Read(void)
{
	unsigned char i;
	unsigned char temp=0;

	SDA_IN();//SDA����Ϊ����
	delay_us(2); 
	for(i=0;i<8;i++)
	{
		temp>>=1;
		TM1668_CLK=0;
		delay_us(2); 
		if(READ_SDA)
			temp|=0x80;
		TM1668_CLK=1;
		delay_us(2); 
	}
	return temp;
}

void Write_COM(unsigned char cmd)		//����������
{
	TM1668_STB=0;
	TM1668_Write(cmd);
	TM1668_STB=1;
}

void Write_DATA(unsigned char add,unsigned char DATA)		//ָ����ַд������
{
	TM1668_STB=0;
	TM1668_Write(0xc0|add); //1100 0000 
	TM1668_Write(DATA);
	TM1668_STB=1;
}

u8 Read_key(void)  //������
{
	unsigned char c[5] = {0,0,0,0,0},i,key_value=0;
	TM1668_STB=0;
	delay_us(2);
	TM1668_Write(0x42);		  //����ɨ���� ����
	for(i=0;i<5;i++)
		{	
			c[i]=TM1668_Read();
		}
	TM1668_STB=1;					           //4���ֽ����ݺϳ�һ���ֽ�
	
	/* 20 ������� */
	if(c[0] != 0)
		{
			if(c[0]==0x01)
				{
					key_value = 16; //Ԥ�� 4 ���ܼ�
				}
			else if(c[0]==0x02)
				{
					key_value=15; //Ԥ�� 3 ���ܼ�
				}
			else if(c[0]==0x10)
				{
					key_value = 3; //���� 3
				}
			else if(c[0]==0x08)
				{
					key_value = 17; //������
				}
//			LCD_ShowxNum(200,10,key_value,2,RED,BLUE);
//			delay_ms(50);
			return key_value;
		}
	if(c[1] != 0)
		{
			if(c[1]==0x01)
				{
					key_value = 18; //���
				}
			else if(c[1]==0x02)
				{
					key_value = 6; // 6
				}
			else if(c[1]==0x08)
				{
					key_value = 19; //����
				}
			else if(c[1]==0x10)
				{
					key_value = 9; //9
				}
//			LCD_ShowxNum(200,10,key_value,2,RED,BLUE);
//			delay_ms(50);
			return key_value;
		}
	if(c[2] != 0)
		{
			if(c[2]==0x01)
				{
					key_value = 20; //OK
				}
			else if(c[2]==0x02)
				{
					key_value = 12; //#
				}
			else if(c[2]==0x08)
				{
					key_value = 2; //2
				}
			else if(c[2]==0x10)
				{
					key_value = 1; //1
				}
//			LCD_ShowxNum(200,10,key_value,2,RED,BLUE);
//			delay_ms(50);
			return key_value;
		}
	if(c[3] != 0)
		{
			if(c[3]==0x01)
				{
					key_value = 14; //Ԥ�� 2 ���ܼ�
				}
			else if(c[3]==0x02)
				{
					key_value = 13; //Ԥ�� 1 ���ܼ�
				}
			else if(c[3]==0x08)
				{
					key_value = 5; //5
				}
			else if(c[3]==0x10)
				{
					key_value = 4; //4
				}
//			LCD_ShowxNum(200,10,key_value,2,RED,BLUE);
//			delay_ms(50);
			return key_value;
		}
	if(c[4] != 0)
		{
			if(c[4]==0x01)
				{
					key_value = 8; //8
				}
			else if(c[4]==0x02)
				{
					key_value = 7; //7
				}
			else if(c[4]==0x08)
				{
					key_value = 11; //0
				}
			else if(c[4]==0x10)
				{
					key_value = 10; //*
				}
			//LCD_ShowxNum(200,10,key_value,2,RED,BLUE);
			//delay_ms(50);
			return key_value;
		}
	return 0;
}

u8 KEY_Scan(u8 mode)
{	 
	static u8 key_up=1;//�������ɿ���־
	if(mode)key_up=1;  //֧������		  
	if(key_up&&(Read_key() != 0))
	{
		delay_ms(10);//ȥ���� 
		key_up=0;
		if(Read_key() != 0)return Read_key();
	}else if(Read_key()==0)key_up=1; 	    
 	return 0;// �ް�������
}

